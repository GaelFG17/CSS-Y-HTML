<?php
  session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Panel - Mostrar Alumnos</title>
  <link rel="stylesheet" href="css/estilos-p.css">
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <link rel="stylesheet" href="css/estilos-cal-btn.css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.css" rel="stylesheet" />
</head>
<body>
  <aside class="sidebar" id="sidebar">
  <div class="user-info">
      <?php
        if (isset($_SESSION['foto'])){
      ?>
        <img src="<?php echo $_SESSION['foto'];?>" alt="User Image">
      <h4><?php echo $_SESSION['usuario'];?></h4>
      <?php
            }else{
              ?>
              <img src="recursos/logo/user.jpeg" alt="User Image">
              </div>
              <div class="info">
                <a href="#" class="d-block">USER</a>
              <?php
            }
          ?>
    </div>
    <ul class="menu">
      <li class="menu-item">
        <button class="menu-title" id="toggle-alumnos-menu">Alumnos</button>
        <ul class="sub-menu" id="alumnos-menu">
          <li><button onclick="window.location.href='/mostrar-alumnos.php'">Mostrar alumnos</button></li>
          <li><button onclick="window.location.href='registrar-alumno.php'">Registrar alumno</button></li>
        </ul>
      </li>
      <li class="menu-item">
        <button class="menu-title" id="toggle-calificaciones-menu">Calificaciones</button>
        <ul class="sub-menu" id="calificaciones-menu">
          <li><button onclick="window.location.href='mostrar-cal.php'">Mostrar calificaciones</button></li>
          <li><button onclick="window.location.href='registrar-calificacion.php'">Registrar calificación</button></li>
          <?php
            if(isset($_POST['cmbEva'])){
          ?>
          <button onclick="window.location.href='reporte.php?grado=<?php echo $_POST['cmbGrado'];?>&grupo=<?php echo $_POST['cmbGrupo'];?>&maestro=<?php echo $_SESSION['usuario'];?>&eva=<?php echo $_POST['cmbEva'];?>'">Reporte</button>
          <?php
            }else{
              echo "Necesita generar las calificaciones para el reporte";
            }
            ?>
        </ul>
      </li>
    </ul>
    <button id="toggle-sidebar" class="toggle-btn">Ocultar</button>
    <!-- Botón para cerrar sesión -->
    <button onclick="window.location.href='cerrar.php'" class="toggle-btn">Cerrar sesión</button>
  </aside>

  <div class="content">
    <h1>Mostrar Calificaciones</h1>
        <?php
            if(isset($_SESSION['usuario'])){
                if($_SESSION['rol'] == 1 || $_SESSION['rol'] == 2){
                    ?>
                    <form method="post">
                    <div class="form-container">
                    <select class="form-control" id="categoria" name="cmbGrado" required>
                        <option value="no" selected>Seleccionar Grado</option>
                            <?php 
                                include("conexion/conectar.php");
                                $sql="CALL proc_verGRADO()";
                                $grados = mysqli_query($cn,$sql);
                                while ($reggrados = mysqli_fetch_assoc($grados)){
                                    echo "<option value='". $reggrados['Id_Grado']. "'>". $reggrados['Nombre_Grado']."</option>";
                                }
                                mysqli_close($cn);
                            ?>
                    </select>
                    <select class="form-control" id="categoria" name="cmbGrupo" required>
                        <option value="no" selected>Seleccionar Grupo</option>
                        <option value="A" >A</option>
                        <option value="B" >B</option>
                    </select>
                    <select class="form-control" id="categoria" name="cmbEva" required>
                        <option value="no" selected>Seleccionar Evaluacion</option>
                        <option value="1" >1ra</option>
                        <option value="2" >2da</option>
                        <option value="3" >3ra</option>
                        <option value="4" >4ta</option>
                    </select>                         
                    <button type="submit" class="btn btn-outline-primary btn-lg mx-2" id="mostrarButton">Mostrar</button>
                    </div>
                    </form>
                <?php
                    if(isset($_POST['cmbGrado']) && isset($_POST['cmbGrupo'])){
                        include("conexion/conectar.php");
                        $maestro = $_SESSION['usuario'];
                        $grado = $_POST['cmbGrado'];
                        $grupo = $_POST['cmbGrupo'];
                        $eva = $_POST['cmbEva'];
                            //preparara para obtener los datos del libro
                        $sql ="Call InfoAlumno2('$maestro', '$grado', '$grupo', '$eva')";
    
                        echo '<table class="table table-striped table-bordered table-hover">';
                        echo '<thead class="thead-dark">';
                        echo '<tr>';
                        echo '<th class="text-center" scope="col">NOMBRE</th>';
                        echo '<th class="text-center" scope="col">EVALUACION</th>';
                        echo '<th class="text-center" scope="col">TIPO</th>';
                        echo '<th class="text-center" scope="col">CALIFICACION</th>';
                        echo '<th class="text-center" scope="col">HORA CLASE</th>';
                        echo '<th class="text-center" scope="col">GRADO</th>';
                        echo '<th class="text-center" scope="col">GRUPO</th>';
                        echo '<th class="text-center" scope="col">SALON</th>';
                        echo '</tr>';
                        echo '</thead>';
                        echo '<tbody>';
                        //ejecutar la consulta 
                        $ejectConsulta = mysqli_query($cn,$sql);
                        while($reglibro = mysqli_fetch_assoc($ejectConsulta)){
                            echo '<tr>';
                            echo '<td class="text-center">' . $reglibro['Nombre_Alumno'] . '</td>';
                            echo '<td class="text-center">' . $reglibro['Evaluacion'] . '</td>';
                            echo '<td class="text-center">' . $reglibro['Tipo'] . '</td>';
                            echo '<td class="text-center">' . $reglibro['Valor_Calificacion'] . '</td>';
                            echo '<td class="text-center">' . $reglibro['Hora_Clase'] . '</td>';
                            echo '<td class="text-center">' . $reglibro['Grado'] . '</td>';
                            echo '<td class="text-center">' . $reglibro['Grupo'] . '</td>';
                            echo '<td class="text-center">' . $reglibro['Salon'] . '</td>';
                            echo '</tr>';
                        }
                        echo '</tbody>';
                        echo '</table>';
                        mysqli_close($cn);
                    }
                }else{
                    echo '<div class="alert alert-warning text-center" role="alert">No tiene privilegios, solo administradores</div>';
                }
            }else{
                echo '<div class="alert alert-info text-center" role="alert">Para ingresar debes <a href="index.php" class="alert-link  text-decoration-none text-danger">Iniciar Sesión</a></div>';
            }
        ?>

</div>
<script src="extras/principal.js"></script>
</body>
</html>

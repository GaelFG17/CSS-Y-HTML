<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Panel - Mostrar Alumnos</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.css" rel="stylesheet" />
</head>

<body class="bg-blue-200 flex flex-col min-h-screen">
  <nav class="bg-blue-900 border-gray-200 dark:bg-gray-900 dark:border-gray-700">
    <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
      <a href="index.php" class="flex items-center space-x-3 rtl:space-x-reverse">
        <img src="recursos/logo/erudito.png" class="h-8" alt="Flowbite Logo" />
        <span class="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">Erudito</span>
      </a>
      <button data-collapse-toggle="navbar-dropdown" type="button" class="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden" aria-controls="navbar-dropdown" aria-expanded="false">
        <span class="sr-only">Open main menu</span>
        <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 17 14">
          <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 1h15M1 7h15M1 13h15" />
        </svg>
      </button>
      <div class="hidden w-full md:block md:w-auto" id="navbar-dropdown">
        <ul class="flex flex-col font-medium p-4 md:p-0 mt-4 md:space-x-8 rtl:space-x-reverse md:flex-row md:mt-0 md:border-0">
          <li>
            <a href="principal.php" class="block py-2 px-3 text-white bg-blue-700 rounded md:bg-transparent md:text-blue-700 md:p-0 md:dark:text-blue-500 dark:bg-blue-600 md:dark:bg-transparent" aria-current="page">Inicio</a>
          </li>
          <li>
            <a href="#" class="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Contactanos</a>
          </li>
          <?php
          if (isset($_SESSION['usuario'])) {
          ?>
            <div class="flex items-center md:order-2 space-x-3 md:space-x-0 rtl:space-x-reverse">
              <button type="button" class="flex text-sm bg-gray-800 rounded-full md:me-0 focus:ring-4 focus:ring-gray-300 dark:focus:ring-gray-600" id="user-menu-button" aria-expanded="false" data-dropdown-toggle="user-dropdown" data-dropdown-placement="bottom">
                <span class="sr-only">Open user menu</span>
                <img class="w-8 h-8 rounded-full" src=<?php echo $_SESSION['foto']; ?> alt="user photo">
              </button>
              <!-- Dropdown menu -->
              <div class="z-50 hidden my-4 text-base list-none bg-white divide-y divide-gray-100 rounded-lg shadow dark:bg-gray-700 dark:divide-gray-600" id="user-dropdown">
                <div class="px-4 py-3">
                  <span class="block text-sm text-gray-900 dark:text-white"><?php if (isset($_SESSION['usuario'])) {
                                                                              echo $_SESSION['usuario'];
                                                                            } else {
                                                                              echo "Bonnie Green";
                                                                            } ?></span>
                  <span class="block text-sm  text-gray-500 truncate dark:text-gray-400"><?php if (isset($_SESSION['correo'])) {
                                                                                            echo $_SESSION['correo'];
                                                                                          } else {
                                                                                            echo "name@flowbite.com";
                                                                                          } ?></span>
                </div>
                <ul class="py-2" aria-labelledby="user-menu-button">
                  <li>
                    <a href="clases.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white">Mis Clases</a>
                  </li>
                  <li>
                    <a href="cerrar.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white">Cerrar Sesion</a>
                  </li>
                </ul>
              </div>
              <button data-collapse-toggle="navbar-user" type="button" class="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="navbar-user" aria-expanded="false">
                <span class="sr-only">Open main menu</span>
                <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 17 14">
                  <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 1h15M1 7h15M1 13h15" />
                </svg>
              </button>
            </div>
          <?php
          } else {
          ?>
            <li>
              <a href="index.php" class="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Iniciar Sesion</a>
            </li>
          <?php
          }
          ?>
        </ul>
      </div>
    </div>
  </nav>

  <div class="flex flex-col items-center justify-center mt-8">
    <form class="max-w-md w-full mb-4" method="GET" action="mostrar-alumnos.php">
      <label for="default-search" class="mb-2 text-sm font-medium text-gray-900 sr-only dark:text-white">Search</label>
      <div class="relative">
        <div class="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
          <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z" />
          </svg>
        </div>
        <input type="search" id="default-search" name="q" class="block w-full p-4 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Buscar Alumno" required />
        <button type="submit" class="text-white absolute end-2.5 bottom-2.5 bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Search</button>
      </div>
    </form>

    <div class="relative overflow-x-auto shadow-md sm:rounded-lg max-w-screen-lg w-full">
      <?php
      if (isset($_SESSION['usuario'])) {
        if ($_SESSION['rol'] == 1 || $_SESSION['rol'] == 2) {
          include("conexion/conectar.php");
          $maestro = $_SESSION['usuario'];

          if (isset($_GET['q']) && !empty($_GET['q'])) {
            $query = $_GET['q'];
            if (strpos($query, ' ') !== false) {
              $sql = "CALL proc_BuscarAlumno('$query')";
            } else {
              $sql = "CALL proc_BuscarAlumnos('$query')";
            }
          } else {
            $sql = "CALL mostrar_alumnos()";
          }

          echo '<table class="w-full text-sm text-left rtl:text-right text-white-500 dark:text-dark-400">';
          echo '<thead class="text-xs text-white-700 uppercase bg-blue-950 text-white">';
          echo '<tr>';
          echo '<th scope="col" class="px-6 py-3">Nombre</th>';
          echo '<th scope="col" class="px-6 py-3">Apellido Paterno</th>';
          echo '<th scope="col" class="px-6 py-3">Apellido Materno</th>';
          echo '</tr>';
          echo '</thead>';
          echo '<tbody>';

          // Ejecutar la consulta
          $result = mysqli_query($cn, $sql);
          if ($result) {
            while ($verClase = mysqli_fetch_assoc($result)) {
              echo '<tr class="bg-white border-b blue:bg-gray-800 dark:border-blue-900">';
              echo '<td scope="col" class="px-6 py-3">' . $verClase['Nombre_Alumno'] . '</td>';
              echo '<td scope="col" class="px-6 py-3">' . $verClase['Ap1_Alumno'] . '</td>';
              echo '<td scope="col" class="px-6 py-3">' . $verClase['Ap2_Alumno'] . '</td>';
              echo '</tr>';
            }
            mysqli_free_result($result);
          } else {
            echo '<tr><td colspan="5">No se encontraron clases.</td></tr>';
          }

          echo '</tbody>';
          echo '</table>';
          mysqli_close($cn);

          // Mostrar enlace para volver a la vista general
          if (isset($_GET['q']) && !empty($_GET['q'])) {
            echo '<p><a href="mostrar-alumnos.php" class="text-blue-700 hover:underline">Cancelar Busqueda</a></p>';
          }
        } else {
          echo '<div class="alert alert-warning text-center" role="alert">No tiene privilegios, solo administradores</div>';
        }
      } else {
        echo '<div class="alert alert-info text-center" role="alert">Para ingresar debes <a href="index.php" class="alert-link  text-decoration-none text-danger">Iniciar Sesión</a></div>';
      }
      ?>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.js"></script>
</body>

</html>
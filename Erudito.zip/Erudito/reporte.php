<?php
include('conexion/fpdf.php');
include('conexion/conectar.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 10);
//$pdf->Image('recursos/Imagenes/imagen.jpeg' , 10 ,8, 10 , 13,);
$pdf->Cell(18, 10, '', 0);
$pdf->Cell(150, 10, 'REPORTE DE CALIFICACIONES', 0);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(50, 10, 'Fecha: '.date('d-m-Y').'', 0);
$pdf->Ln(15);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(80, 8, '', 0);
$pdf->Cell(100, 8, 'ERUDITO', 0);
$pdf->Ln(23);
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(22, 8, 'NOMBRE', 0);
$pdf->Cell(22, 8, 'EVALUACION', 0);
$pdf->Cell(22, 8, 'TIPO', 0);
$pdf->Cell(22, 8, 'CALIFICACION', 0);
$pdf->Cell(22, 8, 'HORARIO', 0);
$pdf->Cell(22, 8, 'GRADO', 0);
$pdf->Cell(22, 8, 'GRUPO', 0);
$pdf->Cell(22, 8, 'SALON', 0);
$pdf->Ln(8);
$pdf->SetFont('Arial', '', 8);
//CONSULTA
$grado = $_GET['grado'];
$grupo = $_GET['grupo'];
$maestro = $_GET['maestro'];
$eva = $_GET['eva'];
    //preparara para obtener los datos del libro
$sql ="Call InfoAlumno2('$maestro', '$grado', '$grupo', '$eva')";
$ejectConsulta = mysqli_query($cn,$sql);
while($result = mysqli_fetch_array($ejectConsulta)){
	$pdf->Cell(22, 8, $result[0], 0);
	$pdf->Cell(22, 8, $result[1], 0);
	$pdf->Cell(22, 8, $result[2], 0);
	$pdf->Cell(22, 8, $result[3], 0);
	$pdf->Cell(22, 8, $result[4], 0);
	$pdf->Cell(22, 8, $result[6], 0);
	$pdf->Cell(22, 8, $result[7], 0);
	$pdf->Cell(22, 8, $result[8], 0);
    $pdf->Ln(8);
}
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(114,8,'',0);
$pdf->Cell(31,8,'Sistema Escolar | ERUDITO',0);
$pdf->Output();
?>
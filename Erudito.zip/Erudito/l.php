<?php
    if(isset($_POST['txtEmail'])){
        $user = $_POST['txtEmail'];
        $passw = $_POST['txtPassword']; 
        include('conectar/conectar.php');
        $sql = "SELECT *FROM usuario
                 WHERE email = '$user' AND
                 contrasenia = MD5('$passw')";

        $ejecSql = mysqli_query($cn, $sql);
        $regUsuario = mysqli_fetch_assoc($ejecSql);
        if(mysqli_affected_rows($cn)==1){
            session_start();

            //
            $_SESSION['usuario'] = $regUsuario['Usuario'];
            $_SESSION['correo'] = $regUsuario['Correo'];
            $_SESSION['foto'] = $regUsuario['Foto'];
            $_SESSION['rol'] = $regUsuario['Cargo'];
            header("location:principal.php");
        }else{
            echo "NO";
        }
    }
    ?>
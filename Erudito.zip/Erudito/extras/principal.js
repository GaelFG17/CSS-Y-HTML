document.addEventListener("DOMContentLoaded", function() {
  const sidebar = document.getElementById("sidebar");
  const toggleSidebarBtn = document.getElementById("toggle-sidebar");
  const toggleAlumnosMenuBtn = document.getElementById("toggle-alumnos-menu");
  const toggleCalificacionesMenuBtn = document.getElementById("toggle-calificaciones-menu");

  toggleSidebarBtn.addEventListener("click", function() {
    sidebar.classList.toggle("collapsed");
  });

  toggleAlumnosMenuBtn.addEventListener("click", function() {
    const alumnosMenu = document.getElementById("alumnos-menu");
    alumnosMenu.classList.toggle("collapsed");

    // Agrega la clase 'active' al botón de alumnos y quita la clase 'active' del botón de calificaciones
    toggleAlumnosMenuBtn.classList.add("active");
    toggleCalificacionesMenuBtn.classList.remove("active");
  });

  toggleCalificacionesMenuBtn.addEventListener("click", function() {
    const calificacionesMenu = document.getElementById("calificaciones-menu");
    calificacionesMenu.classList.toggle("collapsed");

    // Agrega la clase 'active' al botón de calificaciones y quita la clase 'active' del botón de alumnos
    toggleCalificacionesMenuBtn.classList.add("active");
    toggleAlumnosMenuBtn.classList.remove("active");
  });
});

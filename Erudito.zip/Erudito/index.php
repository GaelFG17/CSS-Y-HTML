<?php
    if(isset($_POST['username'])){
        $user = $_POST['username'];
        $passw = $_POST['password']; 
        include('conexion/conectar.php');
        $sql = "SELECT * FROM personas
                 WHERE Correo = '$user' AND
                 Contrasenia = MD5('$passw')";

        $ejecSql = mysqli_query($cn, $sql);
        $regUsuario = mysqli_fetch_assoc($ejecSql);
        if(mysqli_affected_rows($cn)==1){
            session_start();

            //
            $_SESSION['usuario'] = $regUsuario['Usuario'];
            $_SESSION['correo'] = $regUsuario['Correo'];
            $_SESSION['foto'] = $regUsuario['Foto'];
            $_SESSION['rol'] = $regUsuario['Cargo'];
            header("location:principal.php");
        }else{
            echo "NO";
        }
    }
    ?>

<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Iniciar sesión - Administración de Calificaciones</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.css" rel="stylesheet" />
</head>

<body class="bg-blue-200 flex flex-col min-h-screen">
  <nav class="bg-blue-900 border-gray-200 dark:bg-gray-900 dark:border-gray-700 w-full">
    <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
      <a href="index.php" class="flex items-center space-x-3 rtl:space-x-reverse">
        <img src="recursos/logo/erudito.png" class="h-8" alt="Flowbite Logo" />
        <span class="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">Erudito</span>
      </a>
      <button data-collapse-toggle="navbar-dropdown" type="button" class="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden" aria-controls="navbar-dropdown" aria-expanded="false">
        <span class="sr-only">Open main menu</span>
        <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 17 14">
          <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 1h15M1 7h15M1 13h15" />
        </svg>
      </button>
      <div class="hidden w-full md:block md:w-auto" id="navbar-dropdown">
        <ul class="flex flex-col font-medium p-4 md:p-0 mt-4 md:space-x-8 rtl:space-x-reverse md:flex-row md:mt-0 md:border-0">
          <li>
            <a href="principal.php" class="block py-2 px-3 text-white bg-blue-700 rounded md:bg-transparent md:text-blue-700 md:p-0 md:dark:text-blue-500 dark:bg-blue-600 md:dark:bg-transparent" aria-current="page">Inicio</a>
          </li>
          <li>
            <a href="iniciar_sesion.php" class="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Iniciar Sesion</a>
          </li>
          <li>
            <a href="#" class="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Contactanos</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="flex-grow flex items-center justify-center">
    <div class="bg-white rounded-lg shadow-lg flex w-3/4 max-w-4xl">
      <!-- Left Section -->
      <div class="w-1/2 p-8 bg-blue-50 flex flex-col justify-center items-center">
        <div class="mb-4">
          <img src="recursos/logo/erudito.png" alt="Logo" class="w-24 h-24">
        </div>
        <p class="text-center text-blue-600 font-semibold">
          "Sistematizando el futuro educativo: Nuestra dedicación para una nueva generación."
        </p>
      </div>
      <!-- Right Section -->
      <div class="w-1/2 p-8">
        <h2 class="text-2xl font-bold text-blue-600 mb-6">Inicias Sesion</h2>
        <p class="mb-6">Por favor ingrese sus credenciales para ingresar al sistema</p>
        <form action="index.php" method="post">
          <div class="mb-4">
            <label for="username" class="block text-gray-700">Email</label>
            <input type="text" id="username" name="username" class="w-full p-2 border border-gray-300 rounded mt-1" required>
          </div>
          <div class="mb-6">
            <label for="password" class="block text-gray-700">Contraseña</label>
            <input type="password" id="password" name="password" class="w-full p-2 border border-gray-300 rounded mt-1" required>
          </div>
          <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition duration-300">Iniciar sesión</button>
        </form>
      </div>
    </div>
  </div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.js"></script>
</body>

</html>
